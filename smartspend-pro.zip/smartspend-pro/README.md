# 💸 SmartSpend Pro — AI-Powered Expense Tracker

A responsive, single-page expense tracker built for students. Log expenses, set a monthly budget, and get real-time charts and rule-based "AI" budget insights — no backend, no build step.

> Third Year IT Engineering Mini Project (2025–26) · Govindrao Wanjari College of Engineering and Technology (GWCET), Nagpur · Dr. Babasaheb Ambedkar Technological University (Dr. BATU), Lonere

## ✨ Features

- **Expense tracking** across 6 categories (Food, Transport, Study, Entertainment, Health, Other)
- **Monthly budget** with an animated progress bar and 10-step milestones
- **Rule-based AI insights**: smart tips based on budget usage, top category, and spending patterns
- **Interactive charts** (Chart.js): category doughnut, daily trend line, and bar chart
- **Transactions tab**: search, and sort by latest / highest / lowest / name
- **Statistics tab**: biggest expense, daily average, top category, category rings
- **Dark / light theme** toggle, toast notifications, confetti when the budget is exceeded
- **Responsive** layout for desktop and mobile

## 🛠️ Tech Stack

HTML5 · CSS3 (Grid, Flexbox, animations) · Vanilla JavaScript (ES6) · [Chart.js 4.4.1](https://www.chartjs.org/) · HTML5 Canvas (particle background)

## 🚀 Run Locally

No installation needed.

```bash
git clone https://github.com/<your-username>/smartspend-pro.git
cd smartspend-pro
```

Then open `index.html` in any modern browser, or serve it:

```bash
python3 -m http.server 8000   # then visit http://localhost:8000
```

> Chart.js and Google Fonts load from CDNs, so an internet connection is needed on first load.

## 📁 Project Structure

```
smartspend-pro/
├── index.html      # Markup and page structure
├── css/
│   └── style.css   # Theme, layout, animations
├── js/
│   └── app.js      # State, rendering, charts, insights engine
├── README.md
├── LICENSE
└── .gitignore
```

## 🧠 Concepts Demonstrated

- DOM manipulation and event handling
- Data structures (arrays, objects) for state management
- Responsive CSS Grid and Flexbox
- Data visualization with Chart.js
- Rule-based decision engine for budget advice
- CSS animations and micro-interactions
- Canvas API particle animation

## 📌 Notes

Data is held in memory only, so it resets on page refresh. Persisting to `localStorage` is a natural next step.

## 👤 Author

**Sudhanshu** — Final-year IT Engineering, GWCET Nagpur

## 📄 License

Released under the [MIT License](LICENSE).
