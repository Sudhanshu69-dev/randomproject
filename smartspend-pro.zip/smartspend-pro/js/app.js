// ─── STATE ───────────────────────────────────────────────────────────
let expenses = [];
let budget = 5000;
let selectedCat = 'Food';
let sortMode = 'date';
let pieChart = null, lineChart = null, barChart = null;

const CAT = {
  Food:          {color:'#ff6b9d',bg:'rgba(255,107,157,0.12)',emoji:'🍔'},
  Transport:     {color:'#7b61ff',bg:'rgba(123,97,255,0.12)',emoji:'🚌'},
  Study:         {color:'#00f5d4',bg:'rgba(0,245,212,0.1)',emoji:'📚'},
  Entertainment: {color:'#ffbe0b',bg:'rgba(255,190,11,0.1)',emoji:'🎮'},
  Health:        {color:'#06d6a0',bg:'rgba(6,214,160,0.1)',emoji:'💊'},
  Other:         {color:'#8892b0',bg:'rgba(136,146,176,0.1)',emoji:'📦'}
};

// ─── INIT ─────────────────────────────────────────────────────────────
window.addEventListener('DOMContentLoaded', () => {
  document.getElementById('inp-date').value = new Date().toISOString().split('T')[0];
  document.getElementById('inp-budget').value = budget;
  initCanvas();
  setTimeout(() => {
    document.getElementById('loader').classList.add('hide');
    toast('SmartSpend Pro loaded!','✅');
  }, 1200);
});

// ─── CANVAS PARTICLE BG ───────────────────────────────────────────────
function initCanvas() {
  const canvas = document.getElementById('bg-canvas');
  const ctx = canvas.getContext('2d');
  let particles = [];
  function resize() { canvas.width = window.innerWidth; canvas.height = window.innerHeight; }
  resize();
  window.addEventListener('resize', resize);
  for (let i = 0; i < 60; i++) {
    particles.push({
      x: Math.random() * canvas.width, y: Math.random() * canvas.height,
      vx: (Math.random() - 0.5) * 0.3, vy: (Math.random() - 0.5) * 0.3,
      r: Math.random() * 2 + 0.5, a: Math.random() * 0.5 + 0.1,
      c: ['#7b61ff','#00f5d4','#ff6b9d','#ffbe0b'][Math.floor(Math.random()*4)]
    });
  }
  function draw() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    particles.forEach(p => {
      p.x += p.vx; p.y += p.vy;
      if (p.x < 0 || p.x > canvas.width) p.vx *= -1;
      if (p.y < 0 || p.y > canvas.height) p.vy *= -1;
      ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      ctx.fillStyle = p.c; ctx.globalAlpha = p.a; ctx.fill();
    });
    // Draw connections
    ctx.globalAlpha = 1;
    particles.forEach((a, i) => {
      particles.slice(i + 1).forEach(b => {
        const d = Math.hypot(a.x - b.x, a.y - b.y);
        if (d < 120) {
          ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y);
          ctx.strokeStyle = `rgba(123,97,255,${0.08 * (1 - d / 120)})`; ctx.lineWidth = 0.5; ctx.stroke();
        }
      });
    });
    requestAnimationFrame(draw);
  }
  draw();
}

// ─── TOAST ────────────────────────────────────────────────────────────
function toast(msg, icon = 'ℹ️', type = '') {
  const c = document.getElementById('toast-container');
  const el = document.createElement('div');
  el.className = 'toast ' + type;
  el.innerHTML = `<span>${icon}</span><span>${msg}</span>`;
  c.appendChild(el);
  setTimeout(() => { el.style.animation = 'slideOut 0.3s ease forwards'; setTimeout(() => el.remove(), 300); }, 3000);
}

// ─── CONFETTI ─────────────────────────────────────────────────────────
function confetti() {
  const colors = ['#7b61ff','#00f5d4','#ff6b9d','#ffbe0b','#06d6a0'];
  for (let i = 0; i < 40; i++) {
    const el = document.createElement('div');
    el.className = 'confetti-piece';
    el.style.cssText = `left:${Math.random()*100}vw;background:${colors[Math.floor(Math.random()*5)]};width:${Math.random()*10+5}px;height:${Math.random()*10+5}px;animation-duration:${Math.random()*2+1.5}s;animation-delay:${Math.random()*0.5}s;transform:rotate(${Math.random()*360}deg);`;
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 3000);
  }
}

// ─── THEME TOGGLE ─────────────────────────────────────────────────────
function toggleTheme() {
  document.body.classList.toggle('light');
  const btn = document.querySelector('.theme-btn');
  btn.textContent = document.body.classList.contains('light') ? '☀️' : '🌙';
}

// ─── TABS ─────────────────────────────────────────────────────────────
function setTab(id) {
  document.querySelectorAll('.tab').forEach((t, i) => {
    const tabs = ['dashboard','transactions','stats','about'];
    t.classList.toggle('active', tabs[i] === id);
  });
  document.querySelectorAll('.tab-section').forEach(s => s.classList.toggle('active', s.id === 'tab-' + id));
  if (id === 'stats') { renderStats(); renderBarChart(); }
  if (id === 'transactions') renderTxList();
}

// ─── SORT ─────────────────────────────────────────────────────────────
function setSort(btn) {
  document.querySelectorAll('.sort-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  sortMode = btn.dataset.sort;
  renderTxList();
}

// ─── CATEGORY SELECT ──────────────────────────────────────────────────
function selectCat(el) {
  document.querySelectorAll('.cat-btn').forEach(b => b.classList.remove('active'));
  el.classList.add('active');
  selectedCat = el.dataset.cat;
}

// ─── ADD EXPENSE ──────────────────────────────────────────────────────
function addExpense() {
  const desc = document.getElementById('inp-desc').value.trim();
  const amt = parseFloat(document.getElementById('inp-amt').value);
  const date = document.getElementById('inp-date').value;
  const nb = parseFloat(document.getElementById('inp-budget').value);
  if (!desc) { toast('Please enter a description', '⚠️', 'warn'); return; }
  if (!amt || amt <= 0) { toast('Enter a valid amount', '⚠️', 'warn'); return; }
  if (!date) { toast('Pick a date', '⚠️', 'warn'); return; }

  const prevPct = budget > 0 ? Math.round(expenses.reduce((s,e)=>s+e.amt,0)/budget*100) : 0;
  if (nb > 0) budget = nb;

  expenses.unshift({ id: Date.now(), desc, amt, cat: selectedCat, date });
  document.getElementById('inp-desc').value = '';
  document.getElementById('inp-amt').value = '';

  const total = expenses.reduce((s,e)=>s+e.amt,0);
  const pct = budget > 0 ? Math.round(total/budget*100) : 0;

  if (pct >= 100 && prevPct < 100) { toast('You exceeded your budget!', '🚨', 'error'); confetti(); }
  else if (pct >= 75 && prevPct < 75) toast('75% of budget used — slow down!', '⚠️', 'warn');
  else if (pct >= 50 && prevPct < 50) toast('Halfway through your budget', 'ℹ️');
  else toast(`Added ₹${Math.round(amt).toLocaleString('en-IN')} for ${desc}`, '✅');

  render();
}

// ─── DELETE ───────────────────────────────────────────────────────────
function deleteExpense(id) {
  const e = expenses.find(x => x.id === id);
  expenses = expenses.filter(x => x.id !== id);
  if (e) toast(`Deleted: ${e.desc}`, '🗑️');
  render();
  renderTxList();
}

// ─── ANIMATED NUMBER ─────────────────────────────────────────────────
function animateNum(el, target) {
  const start = parseInt(el.dataset.val || '0');
  el.dataset.val = target;
  const diff = target - start;
  const dur = 400;
  const st = performance.now();
  function step(now) {
    const p = Math.min((now - st) / dur, 1);
    const ease = 1 - Math.pow(1 - p, 3);
    const cur = Math.round(start + diff * ease);
    el.textContent = '₹' + Math.abs(cur).toLocaleString('en-IN');
    if (p < 1) requestAnimationFrame(step);
  }
  requestAnimationFrame(step);
}

// ─── RENDER ALL ───────────────────────────────────────────────────────
function render() {
  const total = expenses.reduce((s,e) => s+e.amt, 0);
  const remain = budget - total;
  const pct = budget > 0 ? Math.min(Math.round(total/budget*100), 100) : 0;
  const days = [...new Set(expenses.map(e=>e.date))].length || 1;

  animateNum(document.getElementById('m-total'), total);
  animateNum(document.getElementById('m-budget'), budget);
  animateNum(document.getElementById('m-remain'), remain);
  document.getElementById('m-count').textContent = expenses.length;
  document.getElementById('m-avg').textContent = 'Avg: ₹' + Math.round(total/Math.max(days,1)).toLocaleString('en-IN') + '/day';
  document.getElementById('m-budget-sub').textContent = `₹${Math.round(budget).toLocaleString('en-IN')} limit set`;
  document.getElementById('m-remain-sub').textContent = remain >= 0 ? 'Available to spend' : 'Over budget!';

  const fill = document.getElementById('bar-fill');
  fill.style.width = pct + '%';
  fill.className = 'fill ' + (pct >= 90 ? 'danger' : pct >= 70 ? 'warn' : 'ok');
  document.getElementById('bar-pct').textContent = `${pct}% used — ₹${Math.round(Math.max(remain,0)).toLocaleString('en-IN')} remaining`;
  document.getElementById('bar-pct').style.color = pct >= 90 ? 'var(--c6)' : pct >= 70 ? 'var(--c4)' : 'var(--c1)';

  const segments = Math.floor(pct / 10);
  document.querySelectorAll('.ms').forEach((m,i) => m.classList.toggle('lit', i < segments));

  renderDashTx();
  renderPie(total);
  renderLine();
  renderAI(total, remain, pct);
  document.getElementById('tx-count-lbl').textContent = expenses.length + ' record' + (expenses.length !== 1 ? 's' : '');
  document.getElementById('dash-tx-count').textContent = expenses.length + ' expense' + (expenses.length !== 1 ? 's' : '');
}

// ─── DASHBOARD RECENT ─────────────────────────────────────────────────
function renderDashTx() {
  const el = document.getElementById('dash-tx-list');
  const recent = expenses.slice(0, 5);
  if (!recent.length) { el.innerHTML = '<div class="empty-state"><span class="empty-icon">🧾</span><span class="empty-txt">No expenses yet — add one!</span></div>'; return; }
  el.innerHTML = recent.map(e => txHTML(e)).join('');
}

// ─── FULL TX LIST ─────────────────────────────────────────────────────
function renderTxList() {
  const el = document.getElementById('tx-list-full');
  const q = (document.getElementById('tx-search').value || '').toLowerCase();
  let list = expenses.filter(e => !q || e.desc.toLowerCase().includes(q) || e.cat.toLowerCase().includes(q));
  if (sortMode === 'amt-desc') list.sort((a,b) => b.amt - a.amt);
  else if (sortMode === 'amt-asc') list.sort((a,b) => a.amt - b.amt);
  else if (sortMode === 'name') list.sort((a,b) => a.desc.localeCompare(b.desc));
  else list = [...list].sort((a,b) => b.date.localeCompare(a.date));
  document.getElementById('tx-count-lbl').textContent = list.length + ' record' + (list.length !== 1 ? 's' : '');
  if (!list.length) { el.innerHTML = '<div class="empty-state"><span class="empty-icon">🔍</span><span class="empty-txt">No results found</span></div>'; return; }
  el.innerHTML = list.map(e => txHTML(e)).join('');
}

function txHTML(e) {
  const c = CAT[e.cat] || CAT.Other;
  return `<div class="tx-item">
    <div class="tx-avatar" style="background:${c.bg};border:1px solid ${c.color}22">${c.emoji}</div>
    <div class="tx-info">
      <div class="tx-name">${e.desc}</div>
      <div class="tx-meta">
        <span class="cat-tag" style="background:${c.bg};color:${c.color};border:1px solid ${c.color}44">${e.cat}</span>
        ${e.date}
      </div>
    </div>
    <div style="text-align:right;flex-shrink:0">
      <div class="tx-amt" style="color:${c.color}">₹${Math.round(e.amt).toLocaleString('en-IN')}</div>
      <button class="tx-del" onclick="deleteExpense(${e.id})">✕ Remove</button>
    </div>
  </div>`;
}

// ─── PIE CHART ────────────────────────────────────────────────────────
function renderPie(total) {
  const cats = {};
  expenses.forEach(e => { cats[e.cat] = (cats[e.cat] || 0) + e.amt; });
  const labels = Object.keys(cats);
  if (!labels.length) return;
  if (pieChart) pieChart.destroy();
  pieChart = new Chart(document.getElementById('pieChart'), {
    type: 'doughnut',
    data: {
      labels,
      datasets: [{ data: labels.map(l => Math.round(cats[l])), backgroundColor: labels.map(l => (CAT[l]||CAT.Other).color), borderWidth: 2, borderColor: '#080d1e', hoverBorderWidth: 3 }]
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      plugins: { legend: { display: false }, tooltip: { callbacks: { label: ctx => ` ₹${ctx.parsed.toLocaleString('en-IN')} (${total>0?Math.round(ctx.parsed/total*100):0}%)` }, backgroundColor: '#0d1530', titleColor: '#e8edff', bodyColor: '#8892b0', borderColor: '#ffffff22', borderWidth: 1 } },
      cutout: '62%', animation: { animateScale: true }
    }
  });
  const legend = document.getElementById('pie-legend');
  legend.innerHTML = labels.map(l => `<div style="display:flex;align-items:center;gap:5px;font-size:11px;color:var(--muted2)"><div style="width:8px;height:8px;border-radius:2px;background:${(CAT[l]||CAT.Other).color};flex-shrink:0"></div>${l}: ₹${Math.round(cats[l]).toLocaleString('en-IN')}</div>`).join('');
}

// ─── LINE CHART ───────────────────────────────────────────────────────
function renderLine() {
  const byDate = {};
  expenses.forEach(e => { byDate[e.date] = (byDate[e.date]||0) + e.amt; });
  const dates = Object.keys(byDate).sort();
  if (!dates.length) return;
  if (lineChart) lineChart.destroy();
  lineChart = new Chart(document.getElementById('lineChart'), {
    type: 'line',
    data: { labels: dates.map(d=>d.slice(5)), datasets: [{ data: dates.map(d=>Math.round(byDate[d])), borderColor: '#7b61ff', backgroundColor: 'rgba(123,97,255,0.08)', tension: 0.45, pointRadius: 4, pointBackgroundColor: '#7b61ff', pointBorderColor: '#080d1e', pointBorderWidth: 2, fill: true }] },
    options: {
      responsive: true, maintainAspectRatio: false,
      plugins: { legend: { display: false }, tooltip: { callbacks: { label: ctx => ` ₹${ctx.parsed.y.toLocaleString('en-IN')}` }, backgroundColor: '#0d1530', titleColor: '#e8edff', bodyColor: '#8892b0', borderColor: '#ffffff22', borderWidth: 1 } },
      scales: {
        y: { beginAtZero: true, grid: { color: 'rgba(255,255,255,0.04)' }, ticks: { color: '#5a6494', font: { size: 10, family: 'JetBrains Mono' }, callback: v => '₹'+v } },
        x: { grid: { display: false }, ticks: { color: '#5a6494', font: { size: 10 }, autoSkip: true, maxTicksLimit: 7 } }
      }
    }
  });
}

// ─── BAR CHART ────────────────────────────────────────────────────────
function renderBarChart() {
  const byDay = {};
  expenses.forEach(e => { byDay[e.date] = (byDay[e.date]||0) + e.amt; });
  const dates = Object.keys(byDay).sort().slice(-10);
  if (!dates.length) return;
  if (barChart) barChart.destroy();
  barChart = new Chart(document.getElementById('barChart'), {
    type: 'bar',
    data: { labels: dates.map(d=>d.slice(5)), datasets: [{ data: dates.map(d=>Math.round(byDay[d])), backgroundColor: dates.map((_,i)=>`hsl(${180+i*25},80%,60%)`), borderRadius: 8, borderSkipped: false }] },
    options: {
      responsive: true, maintainAspectRatio: false,
      plugins: { legend: { display: false }, tooltip: { callbacks: { label: ctx => ` ₹${ctx.parsed.y.toLocaleString('en-IN')}` }, backgroundColor: '#0d1530', titleColor: '#e8edff', bodyColor: '#8892b0', borderColor: '#ffffff22', borderWidth: 1 } },
      scales: {
        y: { beginAtZero: true, grid: { color: 'rgba(255,255,255,0.04)' }, ticks: { color: '#5a6494', font: { size: 10 }, callback: v => '₹'+v } },
        x: { grid: { display: false }, ticks: { color: '#5a6494', font: { size: 10 } } }
      }
    }
  });
}

// ─── STATS ────────────────────────────────────────────────────────────
function renderStats() {
  if (!expenses.length) return;
  const total = expenses.reduce((s,e)=>s+e.amt,0);
  const maxE = expenses.reduce((a,b)=>a.amt>b.amt?a:b);
  const days = [...new Set(expenses.map(e=>e.date))].length || 1;
  const cats = {};
  expenses.forEach(e=>{ cats[e.cat]=(cats[e.cat]||0)+e.amt; });
  const topCat = Object.entries(cats).sort((a,b)=>b[1]-a[1])[0];

  document.getElementById('st-max').textContent = '₹'+Math.round(maxE.amt).toLocaleString('en-IN');
  document.getElementById('st-max-name').textContent = maxE.desc;
  document.getElementById('st-avg').textContent = '₹'+Math.round(total/days).toLocaleString('en-IN');
  document.getElementById('st-top').textContent = topCat[0];
  document.getElementById('st-top-pct').textContent = Math.round(topCat[1]/total*100)+'% of total';

  const grid = document.getElementById('ring-grid');
  const catEntries = Object.entries(cats);
  grid.innerHTML = catEntries.map(([cat, amt]) => {
    const c = CAT[cat] || CAT.Other;
    const pct = total > 0 ? Math.round(amt/total*100) : 0;
    const r = 35, circ = 2*Math.PI*r, offset = circ*(1-pct/100);
    return `<div class="ring-card">
      <div class="ring-wrap">
        <svg width="80" height="80" viewBox="0 0 80 80">
          <circle class="ring-track" cx="40" cy="40" r="${r}"/>
          <circle class="ring-fill" cx="40" cy="40" r="${r}" stroke="${c.color}" stroke-dasharray="${circ}" stroke-dashoffset="${offset}"/>
        </svg>
        <div class="ring-label" style="color:${c.color}">${pct}%</div>
      </div>
      <div class="ring-name">${c.emoji} ${cat}</div>
      <div class="ring-amt" style="color:${c.color}">₹${Math.round(amt).toLocaleString('en-IN')}</div>
    </div>`;
  }).join('');
}

// ─── AI TIPS ─────────────────────────────────────────────────────────
function renderAI(total, remain, pct) {
  const cats = {};
  expenses.forEach(e=>{ cats[e.cat]=(cats[e.cat]||0)+e.amt; });
  const topCat = Object.entries(cats).sort((a,b)=>b[1]-a[1])[0];
  const tips = [];

  if (pct >= 100) tips.push('🚨 Budget exceeded! You\'ve overspent. Review all non-essential expenses and cut back immediately.');
  else if (pct >= 90) tips.push(`🔴 Critical: ${pct}% of budget used. Only ₹${Math.round(remain).toLocaleString('en-IN')} left. Freeze discretionary spending now.`);
  else if (pct >= 70) tips.push(`⚠️ ${pct}% budget used. Be careful — ₹${Math.round(remain).toLocaleString('en-IN')} remaining for the month.`);
  else if (expenses.length > 0) tips.push(`✅ On track! ${pct}% used with ₹${Math.round(remain).toLocaleString('en-IN')} remaining. Keep it up!`);

  if (topCat) { const p = Math.round(topCat[1]/total*100); tips.push(`📊 ${topCat[0]} is your #1 spending category at ${p}% (₹${Math.round(topCat[1]).toLocaleString('en-IN')}). Check if this is expected.`); }
  if ((cats.Food||0) > budget*0.4) tips.push('🍱 Food >40% of budget. Try college mess, batch cooking, or group orders to save ₹600–1200/month.');
  if ((cats.Study||0) > 0) tips.push(`📚 ₹${Math.round(cats.Study).toLocaleString('en-IN')} on Study! Great investment. Check NPTEL, Library Genesis, or college library to reduce costs.`);
  if ((cats.Entertainment||0) > budget*0.2) tips.push('🎮 Entertainment >20% of budget. Set a weekly fun-money limit to stay on track.');
  if (expenses.length >= 5) tips.push('💡 Pro tip: Review your spending every Sunday — it only takes 5 mins and saves thousands over a semester.');
  if (remain < 0) tips.push(`🔴 ₹${Math.round(-remain).toLocaleString('en-IN')} over budget. Prioritize cutting Entertainment & Other categories first.`);

  const grid = document.getElementById('ai-tips');
  grid.innerHTML = tips.length
    ? tips.map(t=>`<div class="ai-tip">${t}</div>`).join('')
    : '<div class="ai-tip">Add some expenses to receive personalized AI-powered budget recommendations and spending insights.</div>';
}

// ─── KEYBOARD SHORTCUT ────────────────────────────────────────────────
document.addEventListener('keydown', e => {
  if (e.key === 'Enter' && document.getElementById('inp-desc') === document.activeElement) addExpense();
});
